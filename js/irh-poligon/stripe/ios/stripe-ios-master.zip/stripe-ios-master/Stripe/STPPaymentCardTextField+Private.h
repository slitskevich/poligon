//
//  STPPaymentCardTextField+Private.h
//  Stripe
//
//  Created by Brian Dorfman on 5/3/17.
//  Copyright © 2017 Stripe, Inc. All rights reserved.
//

#import <Stripe/Stripe.h>

@interface STPPaymentCardTextField (Private)
- (void)commonInit;
@end
