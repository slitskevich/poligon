phraseapp pull -t `fetch-password PhraseApp-access-token`
