//
//  TestImageLoader
//  ManualInstallationTest
//
//  Created by Ben Guo on 6/24/16.
//  Copyright © 2016 stripe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestImageLoader : NSObject

@property (nonatomic, strong, nullable) UIImage *image;

@end
